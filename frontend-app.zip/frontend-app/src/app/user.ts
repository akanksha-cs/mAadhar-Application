//map to entity classs
export class User {

    constructor(public uid:number,
        public uname:string,
        public uadhar:number,
        public url:string,
        public mnumber:DoubleRange,
        public address:string,
        public emailid:string,
        public gender:string,
        public dob:string
        ){}
    }